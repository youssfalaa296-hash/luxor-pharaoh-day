import type { Metadata, Viewport } from "next";
import "./globals.css";
import { PwaRegister } from "../components/PwaRegister";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "LUXOR PHARAOH DAY — يومك الفرعوني في الأقصر",
  description: "اكتشف الأقصر، تحقق من المعلومات المهمة قبل الاختيار أو الدفع، واعرف طريقك بوضوح. منصة رقمية ثنائية اللغة للزائر قبل الوصول وأثناء الرحلة.",
  applicationName: "LUXOR PHARAOH DAY",
  generator: "Next.js",
  keywords: ["Luxor", "Luxor Egypt", "Luxor travel", "Luxor visitor information", "الأقصر", "يومك الفرعوني في الأقصر"],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: "LUXOR PHARAOH DAY",
    title: "LUXOR PHARAOH DAY — Your Pharaoh Day in Luxor",
    description: "Know. Check. Go. — اعرف • اتأكد • اتحرك",
    url: "/",
  },
  twitter: { card: "summary_large_image", title: "LUXOR PHARAOH DAY", description: "Your Pharaoh Day in Luxor · يومك الفرعوني في الأقصر" },
  robots: { index: true, follow: true },
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = {
  themeColor: "#090B10",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}<PwaRegister /></body></html>;
}
