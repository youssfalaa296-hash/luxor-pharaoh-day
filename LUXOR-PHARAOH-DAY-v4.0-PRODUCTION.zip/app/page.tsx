import { PaymentPanel } from "../components/PaymentPanel";
import { VisitorExperience } from "../components/VisitorExperience";

export default function Home() {
  return <>
    <VisitorExperience />
    <PaymentPanel />
  </>;
}
