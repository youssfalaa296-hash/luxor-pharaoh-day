# LUXOR PHARAOH DAY — Core Brand Copy

## Short description
LUXOR PHARAOH DAY is a bilingual digital guide for discovering Luxor, checking important information before choosing or paying, and getting clear next steps. Your Pharaoh Day in Luxor.

## Arabic
منصة رقمية ثنائية اللغة لاكتشاف الأقصر، والتحقق من المعلومات المهمة قبل الاختيار أو الدفع، ومعرفة الخطوة التالية بوضوح. يومك الفرعوني في الأقصر.

## English
A bilingual digital guide to discover Luxor, check important information before choosing or paying, and move forward with clear next steps. Your Pharaoh Day in Luxor.

## Primary tagline
Your Pharaoh Day in Luxor.

## Arabic tagline
يومك الفرعوني في الأقصر.

## Product framework
Know. Check. Go.
اعرف • اتأكد • اتحرك
