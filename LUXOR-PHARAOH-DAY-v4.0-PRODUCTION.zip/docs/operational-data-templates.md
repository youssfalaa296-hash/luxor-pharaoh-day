# Operational Data Templates

## Experience record
- ID
- Arabic title
- English title
- Description AR/EN
- Category
- Duration
- Price type: CONFIRMED / ESTIMATED / STARTING_FROM / NEEDS_CONFIRMATION
- Amount + currency
- Price updated at
- Source
- Verification status
- Last verified at
- Included
- Excluded
- Meeting point
- Cancellation policy
- Provider ID
- Contact method
- Directions
- Published status

## Provider verification record
- Provider ID
- Legal/display name
- Service type
- Contact
- Documents checked (record type only; do not expose sensitive documents publicly)
- Verification date
- Verification result
- Reviewer
- Next review date
- Suspension reason if applicable

## Price update record
- Item ID
- Old value
- New value
- Currency
- Source
- Date/time
- Updated by
- Verification status

## Order/payment record
- Order reference
- Customer-provided contact needed for the order
- Selected service
- Amount
- Payment method
- Transaction reference
- Submission time
- Review status
- Reviewer
- Confirmation time

## Incident/report
- Report ID
- Category
- Related record
- Description
- Evidence reference
- Received at
- Status
- Resolution

## Launch checklist
- Legal entity/status confirmed by official documents
- Required tax registration completed where applicable
- Commercial register completed where applicable
- Activity-specific licence requirement confirmed
- Provider contracts signed where applicable
- Terms/privacy/payment/cancellation policies approved
- Domain/email optional but recommended for professional launch
- Production build verified
- Monitoring/backup process established
- Real customer support channel active
