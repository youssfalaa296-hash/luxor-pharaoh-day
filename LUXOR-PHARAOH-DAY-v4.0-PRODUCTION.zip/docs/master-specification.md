# LUXOR PHARAOH DAY — Master Specification v3.1

**Primary tagline:** Your Pharaoh Day in Luxor.  
**Arabic:** يومك الفرعوني في الأقصر.  
**Product framework:** Know. Check. Go. / اعرف • اتأكد • اتحرك  
**Positioning:** Independent Digital Visitor Information & Local Concierge Platform

## 1. Mission

LUXOR PHARAOH DAY is a mobile-first digital platform for visitors and travelers interested in Luxor. Its core experience is:

**KNOW → CHECK → GO**

- **KNOW / اعرف:** discover useful things to do and practical local information.
- **CHECK / اتأكد:** review prices, sources, update dates, conditions, and verification status before choosing or paying.
- **GO / اتحرك:** continue with directions, transport information, contact options, or an appropriate provider link where legally and operationally permitted.

## 2. Target users

- Visitors planning a Luxor trip before arrival.
- Visitors already in Luxor.
- First-time and returning travelers.
- Users comparing activities, prices, transport, or service conditions.

## 3. Core modules

1. Home / الرئيسية
2. Discover / اكتشف
3. What Can I Do Now? / ماذا يمكنني أن أفعل الآن؟
4. Price Check / تحقق من الأسعار
5. Transport / المواصلات
6. Before You Buy / قبل أن تدفع
7. Pre-Arrival / My Pharaoh Day / يومي الفرعوني
8. Trust & Transparency / الثقة والشفافية
9. Report an Issue / الإبلاغ عن مشكلة
10. FAQ / الأسئلة الشائعة
11. Contact / WhatsApp / تواصل معنا
12. Privacy / الخصوصية
13. Terms / الشروط والأحكام
14. PWA, SEO, accessibility and performance

## 4. Bilingual-first requirement

Arabic and English are first-class languages. Important customer-facing text must have an Arabic and English version, with Arabic-first presentation where appropriate.

- Arabic uses RTL.
- English uses LTR.
- Switching language must preserve the user's current page and entered data where possible.
- Translation strings should be centralized under `/locales/ar` and `/locales/en` rather than duplicated in components.
- Future language expansion: German, French, Italian, Spanish and Russian.

## 5. Trust and data rules

Every important price or factual record should support, where available:

- source
- source URL
- last updated date
- verification status
- notes/conditions
- estimated vs confirmed distinction

Do not present demo data as live verified information. Do not call information official, government-approved, licensed, or provider-verified without documented evidence.

Suggested lifecycle:

**Record → Source Review → Verification → Approval → Publish → Monitor → Update / Expire / Archive**

Expired information must not appear as current information.

## 6. Price Check

Prices are high-trust information. The interface should distinguish:

- Confirmed Price / السعر المؤكد
- Estimated Price / السعر التقديري
- Starting From / يبدأ من
- Per Person / للفرد
- Per Group / للمجموعة
- Last Updated / آخر تحديث
- Source / المصدر
- Check the Price Before Paying / تحقق من السعر قبل الدفع

LUXOR PHARAOH DAY does not guarantee a provider's final price unless a real contractual mechanism exists.

## 7. Transport

Transport information may include transport type, typical/estimated range when reliable, estimated travel time, pickup/drop-off context, contact method, source and update status.

Commercial transport or booking must not be presented as bookable until the required provider, operational and legal arrangements are actually in place.

## 8. Before You Buy

Help visitors check:

- What is included?
- What is not included?
- Price status.
- Source and last update.
- Important conditions.
- Duration.
- Meeting point.
- Cancellation/refund information.
- Provider status where factually verified.

The platform should inform users without making unsupported accusations against providers.

## 9. Payment model in v2.2

The current project does **not** include LINK, card-gateway, payment API, or payment webhook integration.

The documented manual payment method is Vodafone Cash using the project number **01012801568**.

Payment UX must make clear that submitting proof does not automatically confirm payment.

Never request a wallet PIN or OTP.

Suggested order lifecycle:

`PENDING_PAYMENT → PAYMENT_SUBMITTED → PAYMENT_REVIEW → PAYMENT_CONFIRMED → ORDER_CONFIRMED`

Additional states may include rejected, cancelled, refund pending and refunded.

A real backend, proof storage, order database, automatic verification and production payment processing are separate implementation milestones and must not be claimed as active unless actually connected and tested.

## 10. Technical stack

- Next.js
- React
- TypeScript
- npm
- GitHub
- Vercel
- Mobile-first Web/PWA

Production build command:

```text
npm run build
```

The project must **not** use a generic `npx webpack` command as its production build step. Next.js owns the production compilation pipeline.

## 11. Dependency installation and CI

CI must use the committed lockfile and reproducible installation:

```text
npm ci
```

A valid `package-lock.json` is required. If dependencies change, update and commit the lockfile before CI runs.

GitHub Actions should cache npm's dependency data through `actions/setup-node` with `cache: npm` and `cache-dependency-path: package-lock.json`.

## 12. Environment variables

Only variables actually used by the application should be configured.

Current public configuration examples:

```text
NEXT_PUBLIC_SITE_URL
NEXT_PUBLIC_WHATSAPP_NUMBER
```

Public variables must not contain secrets. Secrets such as database credentials, API keys, authentication secrets or payment credentials belong only in the hosting provider/GitHub secret store when the corresponding backend feature exists.

The current manual Vodafone Cash number is not an API secret.

## 13. Deployment settings

Recommended Vercel configuration:

```text
Framework Preset: Next.js
Root Directory: .
Install Command: npm ci
Build Command: npm run build
Output Directory: Default
Development Command: npm run dev
Package Manager: npm
```

Do not prefix commands with `sh` and do not use `npx webpack` as the production build command.

## 14. Security

Never commit:

- passwords
- API secrets
- payment secrets
- private customer data
- authentication secrets

Use HTTPS, environment variables, least-privilege access, validation, rate limiting where appropriate, audit logging, backups and monitoring as production infrastructure is added.

## 15. Legal and operational boundaries

LUXOR PHARAOH DAY is an independent digital platform. It must not be presented as a government service or official tourism authority without actual legal/organizational basis.

Regulated tourism, transportation, booking, financial or payment functionality requires the relevant operational and legal review before activation.

## 16. Release lifecycle

**Development → Preview → QA → Production**

Production readiness is more than a successful build. It also requires appropriate data quality, security, privacy, legal/operational review, monitoring, backups, ownership and QA.

## 17. Product principles

1. Trust before hype.
2. Clarity before complexity.
3. Real information before demo claims.
4. Mobile first.
5. Transparency about uncertainty.
6. Fast path to useful action.
7. No unsupported promises.
8. Security by default.
9. Privacy by design.
10. Build for future scale.

## 18. Current status rule

Always distinguish between:

**CONCEPT / DEMO / PREVIEW / TEST / PRODUCTION / VERIFIED / UNVERIFIED / PLANNED / COMPLETED**

A successful CI build proves compilation/build health only. It does not by itself prove that domain, backend, payment, provider verification, legal status, data accuracy, or commercial operations are complete.
