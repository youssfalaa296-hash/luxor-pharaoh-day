# LUXOR PHARAOH DAY — Production+ Specification

## Objective
A bilingual, mobile-first visitor platform for Luxor following KNOW → CHECK → GO.

## Visitor journey
1. Discover by time, interest and budget.
2. Check source, update date, price type, inclusions and meeting point.
3. Plan a day and save/share options.
4. Get practical transport/directions information.
5. Contact the platform for help.
6. Use manual payment only where the commercial/legal model permits it.

## Trust model
Every changing commercial or operational fact must expose source + last update + status.
Statuses: VERIFIED, CONFIRMED, ESTIMATED, NEEDS_CONFIRMATION, OUTDATED, SUSPENDED.

## Payment model
Current UI supports manual Vodafone Cash review only. Payment proof is not payment confirmation. Never request PIN/OTP.

## Privacy model
Collect only information necessary for the requested action. Avoid account creation for discovery. Location permission should be requested only for a location-dependent feature. Payment/contact data must not be stored in browser localStorage.

## Commercial compliance gate
The site must not represent itself as a government body, licensed tourism company, or approved operator without a valid official basis. Booking, organizing, selling or collecting money for regulated tourism services remains disabled until the legal activity and licensing requirements are confirmed.

## Content model
Experience, provider, price, transport, order and verification records are structured for a future database/admin dashboard.

## Quality gates
- typecheck passes
- production build passes
- no secrets in repository
- no fake reviews/providers/prices/verification
- all public links work
- mobile layout checked
- Arabic RTL and English LTR checked
- accessibility basics checked
- legal copy reviewed before commercial launch
