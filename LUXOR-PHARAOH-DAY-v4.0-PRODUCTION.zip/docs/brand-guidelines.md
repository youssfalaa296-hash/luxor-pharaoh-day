# LUXOR PHARAOH DAY — Brand Guidelines v3.1

## Brand
**Name:** LUXOR PHARAOH DAY
**Arabic:** يومك الفرعوني في الأقصر
**Primary tagline:** Your Pharaoh Day in Luxor.
**Arabic tagline:** يومك الفرعوني في الأقصر.
**Product framework:** Know. Check. Go. / اعرف • اتأكد • اتحرك
**Positioning:** Independent Digital Visitor Information & Local Concierge Platform.

## Brand idea
The identity combines Luxor's ancient Egyptian heritage with a premium, modern digital experience. The brand should feel authentic, refined, confident, clear and useful—not like a generic tour marketplace.

## Visual direction
- Deep night-black foundation: `#090B10`
- Pharaoh gold: `#D7B56D`
- Ivory text: `#F7F3E9`
- Muted sandstone: `#B9B09E`
- Fine gold line: `rgba(215,181,109,.18)`

Gold is an accent, not a full-page fill. Use dark space and restrained geometry to create a premium archaeological/editorial feel.

## Logo
Primary logo asset: `public/logo.svg`.
Use the wordmark with generous clear space. Do not stretch, recolor, rotate, add shadows, or place it over busy imagery.

## Icon direction
Use simple ancient-Egypt-inspired geometry: sun disc, lotus, papyrus, temple columns, cartouche-like frames and restrained crown/Pharaoh references. Avoid copying protected third-party logos or making the identity look like an official government seal.

## Typography
Use a clean modern sans-serif system stack for the interface. Arabic and English must remain readable at mobile sizes. Headings may use strong weight and tracking; body text stays comfortable and spacious.

## Language
Arabic and English are first-class. Arabic is RTL and English is LTR. Important customer-facing content should be bilingual, with Arabic above English where practical.

## Voice
Clear, premium, welcoming, trustworthy and practical. Never promise certainty where the underlying data is only estimated. Never imply government affiliation or official tourism authority status without documented basis.

## Core message
**Know. Check. Go.**
**اعرف • اتأكد • اتحرك**

The visitor should understand the brand in seconds: discover Luxor, check the important details, then move forward with clear next steps.
