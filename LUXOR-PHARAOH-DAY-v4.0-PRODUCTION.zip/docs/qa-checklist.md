# LUXOR PHARAOH DAY — QA Checklist v3.1

## Build
- [ ] `npm ci` succeeds with committed lockfile
- [ ] `npm run typecheck` succeeds
- [ ] `npm run build` succeeds
- [ ] no generic Webpack build command
- [ ] no `sh` command in deployment settings

## Branding
- [ ] LUXOR PHARAOH DAY appears consistently
- [ ] Arabic brand is correct: يومك الفرعوني في الأقصر
- [ ] tagline is consistent
- [ ] logo loads
- [ ] no old brand references remain in application code or customer-facing content

## Bilingual
- [ ] Arabic RTL
- [ ] English LTR
- [ ] important UI is bilingual
- [ ] language switching preserves relevant user state
- [ ] no clipped Arabic text
- [ ] no overflow on mobile

## Trust
- [ ] source displayed where applicable
- [ ] last update displayed where applicable
- [ ] verification status is truthful
- [ ] estimated prices are clearly labeled
- [ ] no fabricated provider or review data

## Payment
- [ ] Vodafone Cash number is correct
- [ ] payment proof is not treated as automatic confirmation
- [ ] PIN/OTP are never requested
- [ ] order reference is generated/handled correctly
- [ ] status transitions are clear

## Responsive UX
- [ ] 360px-class mobile viewport
- [ ] tablet
- [ ] desktop
- [ ] buttons are reachable
- [ ] typography is readable
- [ ] cards do not overlap
- [ ] navigation is usable

## Production
- [ ] domain/DNS verified
- [ ] HTTPS verified
- [ ] environment variables verified
- [ ] backend/storage verified if enabled
- [ ] admin authorization verified
- [ ] privacy/terms reviewed
- [ ] monitoring/backups verified where applicable
