const required = ["NEXT_PUBLIC_SITE_URL", "NEXT_PUBLIC_WHATSAPP_NUMBER"];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(", ")}`);
  process.exit(1);
}
if (!/^https?:\/\//.test(process.env.NEXT_PUBLIC_SITE_URL)) {
  console.error("NEXT_PUBLIC_SITE_URL must start with http:// or https://");
  process.exit(1);
}
if (!/^20\d{10}$/.test(process.env.NEXT_PUBLIC_WHATSAPP_NUMBER)) {
  console.error("NEXT_PUBLIC_WHATSAPP_NUMBER must be an Egyptian WhatsApp number in international digits, e.g. 2010XXXXXXXX");
  process.exit(1);
}
console.log("Environment preflight: OK");
