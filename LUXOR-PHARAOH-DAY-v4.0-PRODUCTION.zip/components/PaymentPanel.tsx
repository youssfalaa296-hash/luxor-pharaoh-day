"use client";

import { useMemo, useState } from "react";
import { CheckCircle2, Copy, ShieldCheck, WalletCards } from "lucide-react";
import { Bilingual } from "./Bilingual";

const paymentNumber = "01012801568";
const whatsappNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "201012801568";

type Status = "PENDING_PAYMENT" | "PAYMENT_SUBMITTED" | "PAYMENT_REVIEW" | "PAYMENT_CONFIRMED";

const statusLabels: Record<Status, { ar: string; en: string }> = {
  PENDING_PAYMENT: { ar: "في انتظار الدفع", en: "Pending Payment" },
  PAYMENT_SUBMITTED: { ar: "تم إرسال إثبات الدفع", en: "Payment Submitted" },
  PAYMENT_REVIEW: { ar: "الدفع قيد المراجعة", en: "Payment Under Review" },
  PAYMENT_CONFIRMED: { ar: "تم تأكيد الدفع", en: "Payment Confirmed" }
};

export function PaymentPanel() {
  const [copied, setCopied] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [transaction, setTransaction] = useState("");
  const [sender, setSender] = useState("");
  const [reference, setReference] = useState("LPD-PENDING");

  const status: Status = useMemo(() => submitted ? "PAYMENT_REVIEW" : "PENDING_PAYMENT", [submitted]);

  async function copyNumber() {
    try {
      await navigator.clipboard.writeText(paymentNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  function submitPayment(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!transaction.trim() || !sender.trim()) return;
    const ref = `LPD-${new Date().getFullYear()}-${transaction.trim().slice(-6).toUpperCase().replace(/[^A-Z0-9]/g, "X")}`;
    setReference(ref);
    const message = [
      "LUXOR PHARAOH DAY — Payment Review",
      `Order Reference: ${ref}`,
      `Transaction Reference: ${transaction.trim()}`,
      `Sender Phone: ${sender.trim()}`,
      "Please review this transfer. I will attach the payment proof in WhatsApp if available.",
    ].join("\n");
    window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
    setSubmitted(true);
  }

  return (
    <section id="payment" className="mx-auto max-w-7xl px-5 py-12 md:px-8">
      <div className="glass overflow-hidden rounded-[2rem] p-6 md:p-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_1.15fr]">
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-amber-200/15 bg-amber-100/5 px-4 py-2 text-xs text-amber-100">
              <WalletCards size={15} />
              <Bilingual ar="الدفع اليدوي" en="Manual Payment" />
            </div>
            <h2 className="text-3xl font-black md:text-5xl">
              <span dir="rtl" className="block">ادفع عبر Vodafone Cash</span>
              <span dir="ltr" className="mt-2 block text-stone-400">Pay via Vodafone Cash</span>
            </h2>
            <p className="mt-5 max-w-xl leading-7 text-stone-400">
              <span dir="rtl" className="block">راجع طلبك، حوّل المبلغ، ثم أرسل بيانات التحويل للمراجعة.</span>
              <span dir="ltr" className="mt-1 block">Review your order, transfer the amount, then submit your transfer details for review.</span>
            </p>

            <div className="mt-7 rounded-3xl border border-amber-200/20 bg-black/20 p-5">
              <div className="text-xs uppercase tracking-[.2em] text-stone-500">Vodafone Cash · رقم الدفع / Payment Number</div>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <code className="text-2xl font-black tracking-wider text-amber-100">{paymentNumber}</code>
                <button type="button" onClick={copyNumber} className="glass rounded-full px-4 py-2 text-sm font-bold" aria-label="Copy Vodafone Cash payment number">
                  <Copy className="mr-2 inline" size={15} />
                  {copied ? "تم النسخ · Copied" : "نسخ الرقم · Copy"}
                </button>
              </div>
            </div>

            <div className="mt-7 grid gap-3">
              {["راجع طلبك والمبلغ قبل التحويل.", "حوّل المبلغ إلى رقم Vodafone Cash الموضح.", "احتفظ برقم العملية أو مرجع التحويل.", "أرسل بيانات التحويل وإثبات الدفع إن وجد.", "انتظر مراجعة الدفع قبل اعتبار الطلب مؤكدًا."].map((ar, i) => (
                <div key={ar} className="flex gap-3 rounded-2xl border border-white/5 bg-white/[.025] p-4">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-100/10 text-sm font-black text-amber-200">{i + 1}</span>
                  <div><div dir="rtl">{ar}</div><div dir="ltr" className="mt-1 text-sm text-stone-500">{["Review your order and amount before transferring.", "Transfer the amount to the Vodafone Cash number shown.", "Keep your transaction or transfer reference.", "Submit your transfer details and payment proof if available.", "Wait for payment review before your order is considered confirmed."][i]}</div></div>
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-2xl border border-amber-300/15 bg-amber-100/[.04] p-4">
              <div className="flex gap-3"><ShieldCheck className="mt-1 shrink-0 text-amber-200" size={20}/><div><div className="font-bold" dir="rtl">تنبيه مهم</div><div className="text-sm text-stone-400" dir="ltr">Important Notice</div><p className="mt-2 text-sm leading-6 text-stone-300" dir="rtl">إرسال إثبات الدفع لا يعني تأكيد الدفع تلقائيًا. يتم التأكيد بعد المراجعة والتحقق. لا تشارك الرقم السري للمحفظة أو رمز OTP.</p><p className="mt-1 text-sm leading-6 text-stone-500" dir="ltr">Submitting payment proof does not automatically confirm payment. Confirmation happens after review and verification. Never share your wallet PIN or OTP.</p></div></div>
            </div>
          </div>

          <div className="rounded-[1.5rem] border border-white/8 bg-black/20 p-5 md:p-7">
            <div className="mb-6"><Bilingual ar="تأكيد التحويل" en="Transfer Confirmation" className="text-xl font-black"/><p className="mt-3 text-sm leading-6 text-stone-500" dir="ltr">Enter your transfer details so we can review the payment and match it to your order.</p></div>
            <div className="mb-6 rounded-2xl border border-white/5 bg-white/[.025] p-4"><div className="text-xs text-stone-500">رقم الطلب · Order Reference</div><div className="mt-2 font-mono font-bold text-amber-100">{reference}</div></div>

            {submitted ? (
              <div className="space-y-5">
                <div className="rounded-3xl border border-emerald-200/15 bg-emerald-100/[.04] p-6">
                  <CheckCircle2 className="text-emerald-200" size={28}/>
                  <div className="mt-4 text-xl font-black" dir="rtl">تم استلام بيانات الدفع</div>
                  <div className="mt-1 text-sm text-stone-400" dir="ltr">Payment details received</div>
                  <p className="mt-4 leading-7 text-stone-300" dir="rtl">تم تجهيز رسالة المراجعة وفتح WhatsApp لإرسال بيانات التحويل. لا يعتبر الطلب مؤكدًا حتى تتم المراجعة.</p>
                  <p className="mt-1 text-sm leading-6 text-stone-500" dir="ltr">Your review message has been prepared and WhatsApp opened. The order is not confirmed until the transfer is reviewed.</p>
                </div>
                <div className="rounded-2xl border border-amber-200/10 p-4"><div className="text-xs text-stone-500">حالة الطلب · Order Status</div><div className="mt-2 font-bold text-amber-100">{statusLabels[status].ar} · {statusLabels[status].en}</div><div className="mt-3 text-sm text-stone-500" dir="rtl">أرفق صورة إثبات الدفع داخل WhatsApp إذا كانت متاحة.</div></div>
                <p className="text-sm text-stone-500" dir="rtl">احتفظ برقم الطلب عند التواصل مع LUXOR PHARAOH DAY.</p>
              </div>
            ) : (
              <form onSubmit={submitPayment} className="space-y-5">
                <label className="block"><Bilingual ar="رقم التحويل / مرجع العملية" en="Transaction Reference" className="mb-2 block text-sm font-bold"/><input required value={transaction} onChange={e => setTransaction(e.target.value)} className="field" placeholder="Transaction reference" /></label>
                <label className="block"><Bilingual ar="رقم الهاتف المُحوِّل" en="Sender Phone Number" className="mb-2 block text-sm font-bold"/><input required inputMode="tel" value={sender} onChange={e => setSender(e.target.value)} className="field" placeholder="01xxxxxxxxx" /></label>
                <div className="grid gap-4 sm:grid-cols-2"><label className="block"><Bilingual ar="تاريخ التحويل" en="Transfer Date" className="mb-2 block text-sm font-bold"/><input type="date" className="field" /></label><label className="block"><Bilingual ar="وقت التحويل" en="Transfer Time" className="mb-2 block text-sm font-bold"/><input type="time" className="field" /></label></div>
                <div className="rounded-2xl border border-amber-200/10 bg-amber-100/[.03] p-4"><Bilingual ar="إثبات الدفع" en="Payment Proof" className="text-sm font-bold"/><p className="mt-2 text-xs leading-5 text-stone-500" dir="rtl">بعد الضغط على الإرسال سيفتح WhatsApp. أرفق صورة أو ملف إثبات الدفع هناك إذا كان متاحًا.</p><p className="mt-1 text-xs leading-5 text-stone-600" dir="ltr">WhatsApp will open after submission. Attach your payment proof there if available.</p></div>
                <button className="w-full rounded-2xl bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 px-5 py-4 font-black text-black shadow-xl shadow-amber-500/10" type="submit"><span dir="rtl">إرسال إثبات الدفع</span><span dir="ltr" className="ml-2">· Submit Payment Proof</span></button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
