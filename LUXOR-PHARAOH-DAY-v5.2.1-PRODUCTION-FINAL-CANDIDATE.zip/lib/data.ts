export type VerificationStatus = 'CHECKED' | 'ESTIMATED' | 'UNVERIFIED' | 'PLANNED';

export type Attraction = {
  id: string;
  titleAr: string;
  titleEn: string;
  hours: string;
  foreignerAdult: number;
  foreignerStudent: number;
  egyptianAdult: number;
  egyptianStudent: number;
  status: VerificationStatus;
  sourceUrl: string;
  lastReviewed: string;
};

export type Experience = {
  id: string;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  category: string;
  durationMinutes: number;
  budget: 'low' | 'medium' | 'high';
  status: VerificationStatus;
  attractionIds: string[];
};

export const attractions: Attraction[] = [
  {
    id: 'karnak', titleAr: 'معبد الكرنك', titleEn: 'Karnak Temple', hours: '06:00–17:00',
    foreignerAdult: 600, foreignerStudent: 300, egyptianAdult: 40, egyptianStudent: 20,
    status: 'CHECKED', lastReviewed: '2026-09-27',
    sourceUrl: 'https://egymonuments.gov.eg/archaeological-sites/karnak/'
  },
  {
    id: 'valley-of-kings', titleAr: 'وادي الملوك', titleEn: 'Valley of the Kings', hours: '06:00–17:00',
    foreignerAdult: 750, foreignerStudent: 375, egyptianAdult: 60, egyptianStudent: 30,
    status: 'CHECKED', lastReviewed: '2026-09-27',
    sourceUrl: 'https://egymonuments.gov.eg/archaeological-sites/valley-of-the-kings'
  },
  {
    id: 'luxor-temple', titleAr: 'معبد الأقصر', titleEn: 'Luxor Temple', hours: '06:00–20:00',
    foreignerAdult: 500, foreignerStudent: 250, egyptianAdult: 40, egyptianStudent: 20,
    status: 'CHECKED', lastReviewed: '2026-09-27',
    sourceUrl: 'https://egymonuments.gov.eg/monuments/luxor-temple'
  },
  {
    id: 'hatshepsut', titleAr: 'معبد حتشبسوت', titleEn: 'Hatshepsut Temple', hours: '06:00–17:00',
    foreignerAdult: 440, foreignerStudent: 220, egyptianAdult: 40, egyptianStudent: 20,
    status: 'CHECKED', lastReviewed: '2026-09-27',
    sourceUrl: 'https://egymonuments.gov.eg/monuments/hatshepsut-temple/'
  }
];

export const experiences: Experience[] = [
  {
    id: 'east-bank-core', titleAr: 'قلب الأقصر الشرقي', titleEn: 'East Bank Core',
    summaryAr: 'الكرنك ثم معبد الأقصر في مسار تاريخي واضح داخل المدينة.',
    summaryEn: 'Karnak followed by Luxor Temple in a clear heritage route across the city.',
    category: 'heritage', durationMinutes: 300, budget: 'medium', status: 'CHECKED', attractionIds: ['karnak','luxor-temple']
  },
  {
    id: 'west-bank-royal', titleAr: 'يوم الضفة الغربية الملكية', titleEn: 'Royal West Bank Day',
    summaryAr: 'وادي الملوك مع معبد حتشبسوت لمسار أثري مركز.',
    summaryEn: 'Valley of the Kings with Hatshepsut Temple for a focused royal heritage route.',
    category: 'history', durationMinutes: 360, budget: 'medium', status: 'CHECKED', attractionIds: ['valley-of-kings','hatshepsut']
  },
  {
    id: 'luxor-sunset', titleAr: 'الأقصر حتى الغروب', titleEn: 'Luxor Through Sunset',
    summaryAr: 'اختيار مسائي مرن حول معبد الأقصر بعد اليوم الأثري.',
    summaryEn: 'A flexible evening option around Luxor Temple after the heritage day.',
    category: 'scenic', durationMinutes: 180, budget: 'low', status: 'ESTIMATED', attractionIds: ['luxor-temple']
  }
];

export const siteConfig = {
  name: 'LUXOR PHARAOH DAY',
  conceptAr: 'أبرز تجربة اليوم الفرعوني في الأقصر',
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL || 'https://luxor-pharaoh-day.vercel.app',
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '',
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || ''
};
