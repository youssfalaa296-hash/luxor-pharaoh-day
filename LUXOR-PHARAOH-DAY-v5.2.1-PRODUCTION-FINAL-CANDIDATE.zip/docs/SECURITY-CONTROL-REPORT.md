# Security Control Report

## Source controls

- `engine-strict=true` protects the runtime contract.
- `.env*` is ignored except `.env.example`.
- Public variables are explicitly documented as public.
- No real contact secret or payment credential is stored in source.

## HTTP controls

`next.config.ts` sets: X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy and X-DNS-Prefetch-Control.

## Product controls

- No payments in the launch baseline.
- No provider-verification claim without supporting evidence.
- No government affiliation claim.
- Time-sensitive facts carry source and review date.

## Production gaps

Server-side rate limiting, audit logging, database backups, authentication, provider onboarding and payment controls are intentionally outside the initial static launch surface and require a separate security/operations design before activation.
