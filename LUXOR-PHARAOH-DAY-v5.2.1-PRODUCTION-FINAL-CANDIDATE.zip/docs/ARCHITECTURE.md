# Architecture

## Frontend

Next.js App Router + TypeScript, mobile-first, RTL-first bilingual UI, local visual assets, and no unnecessary runtime dependencies.

## Core modules

Home / Experiences / Planner / Transport / Before You Buy / Privacy / Terms.

## Trust model

Every mutable visitor-information record should carry a source URL, review date, visitor category where relevant, verification state and notes about volatility.

## Lifecycle

Record → Source review → Verification → Approval → Publish → Monitor → Update / Expire / Archive.

## Launch baseline

The initial system is deliberately static and does not include a database, authentication, payment processing, supplier brokerage or provider-verification workflow.

## Future modules

A backend/database, admin dashboard, authentication, analytics, booking, payments, notifications and provider onboarding may be added only after separate architecture, security, operational and legal review.
