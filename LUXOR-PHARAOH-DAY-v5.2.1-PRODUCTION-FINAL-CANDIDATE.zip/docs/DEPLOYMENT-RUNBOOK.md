# Deployment Runbook

## 1. GitHub

Upload the extracted project files into the repository root. Do not upload the ZIP as the application source.

## 2. Lockfile

Run **Actions → Bootstrap npm 11 lockfile → Run workflow**. The workflow is intentionally the only path allowed to create the production lockfile; it publishes the generated lockfile to an automation branch and opens a PR so the protected `main` branch can keep its signature/history rules.

## 3. CI

After `package-lock.json` is committed, `Production CI` must pass these gates:

`Node 24.21.0 → npm 11.19.0 → npm ci → preflight → project verification → build`

## 4. Vercel

Connect the GitHub repository as a Next.js project. Root `/`, install `npm ci`, build `npm run build`, and set the public canonical URL.

## 5. Production QA

Check the real production origin on a phone and desktop. Verify the application routes, source links, planner persistence, RTL, metadata, robots, sitemap, manifest, and browser console.

## 6. Release status

Only after CI + Vercel READY + browser QA + runtime/error review may the status be changed to Production-Verified.
