# Technical Master Report

## Target runtime

- Node: 24.21.0
- npm: 11.19.0
- Package manager contract: `npm@11.19.0`
- Lockfile requirement: npm-generated `package-lock.json`, lockfileVersion 3

## Application

- Next.js App Router
- React 19.2.0
- TypeScript
- Mobile-first bilingual RTL UI
- Static source-backed visitor data; no database or authentication in the launch baseline

## Production-safe features

- KNOW/CHECK/GO navigation
- Local day planner with browser storage
- Source and review-date display for time-sensitive attraction data
- Animated CSS hero with reduced-motion support
- Metadata, sitemap, robots and manifest
- Error, loading and not-found boundaries
- Security headers

## Removed from the final pack

- Unrelated generic SLSA workflow
- Vercel CLI deployment workflow that depended on unconfigured long-lived Vercel secrets and a floating `vercel@latest` dependency
- Any fake package-lock content
- Fake public email/contact placeholders

## Remaining external activation gates

- Real GitHub write/merge from the connected integration (currently blocked by connector-level HTTP 403 during writes)
- npm registry access for lockfile generation in this isolated local container
- Vercel project linkage and Production deployment
- Browser QA against the real deployed URL
- Legal/commercial activation for any booking, payment, brokerage or provider-verification feature

## Final engineering rule

Production-Verified is a deployment state, not a source-code label. It is granted only after the complete release gate succeeds on one commit.
