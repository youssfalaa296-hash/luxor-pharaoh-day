# Production Checklist

## Prepared in source package

- [x] Node 24.21.0 / npm 11.19.0 contract locked.
- [x] `packageManager` and `engines` pinned to the runtime contract.
- [x] Single lockfile-bootstrap workflow defined.
- [x] Production CI uses `npm ci` only after committed lockfile.
- [x] Security and environment-variable rules documented.
- [x] Source-backed attraction data recorded with review dates and URLs.
- [x] Placeholder public contact values removed.
- [x] Unrelated/floating deployment workflow removed.
- [x] Technical, data, QA, security and lockfile reports included.

## Must still pass on the real repository/deployment

- [ ] Node 24.21.0 runtime gate passes.
- [ ] npm 11.19.0 runtime gate passes.
- [ ] Real npm-generated `package-lock.json` committed.
- [ ] `npm ci` passes.
- [ ] `npm run preflight` passes.
- [ ] `npm run verify` passes.
- [ ] `npm run build` passes.
- [ ] Vercel Production deployment is READY.
- [ ] Browser QA passes on the real production origin.
- [ ] Runtime/error logs are clean.
- [ ] Performance and accessibility measurements are recorded.

Final label only after all release gates pass: **Production-Verified**.
