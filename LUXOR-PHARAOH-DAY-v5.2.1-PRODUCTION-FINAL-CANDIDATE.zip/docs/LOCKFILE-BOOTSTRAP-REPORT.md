# Lockfile Bootstrap Report

Date: 2026-09-27

## Requested contract

- Node 24.21.0
- npm 11.19.0
- npm-generated `package-lock.json`
- lockfileVersion 3

## Local attempt

The execution container currently exposes Node 22.16.0 and npm 10.9.2. A direct attempt to obtain Node 24.21.0 from nodejs.org failed because DNS/network resolution is unavailable in the container.

A second lockfile attempt with the available npm 10 in offline mode failed with `ENOTCACHED` because the npm registry metadata/dependencies are not present in the local cache.

## Result

No fake or hand-written `package-lock.json` was added. The project contains a deterministic GitHub Actions bootstrap workflow that generates the real lockfile on Node 24.21.0/npm 11.19.0 and validates it before CI continues.
