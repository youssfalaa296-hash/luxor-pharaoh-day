# Data Verification Report

Review date: 2026-09-27

The current public attraction prices and hours were cross-checked against the Egyptian Ministry of Tourism and Antiquities monument pages.

| Attraction | Hours | Foreign adult | Foreign student | Egyptian adult | Egyptian student | Source | Review date |
|---|---|---:|---:|---:|---:|---|---|
| Karnak Temple | 06:00–17:00 | 600 EGP | 300 EGP | 40 EGP | 20 EGP | https://egymonuments.gov.eg/archaeological-sites/karnak/ | 2026-09-27 |
| Valley of the Kings | 06:00–17:00 | 750 EGP | 375 EGP | 60 EGP | 30 EGP | https://egymonuments.gov.eg/archaeological-sites/valley-of-the-kings | 2026-09-27 |
| Luxor Temple | 06:00–20:00 | 500 EGP | 250 EGP | 40 EGP | 20 EGP | https://egymonuments.gov.eg/monuments/luxor-temple | 2026-09-27 |
| Hatshepsut Temple | 06:00–17:00 | 440 EGP | 220 EGP | 40 EGP | 20 EGP | https://egymonuments.gov.eg/monuments/hatshepsut-temple/ | 2026-09-27 |

## Operational note

These values are source snapshots. Prices, eligibility, opening hours, and ticket rules can change. The UI exposes the source and review date rather than treating them as permanent guarantees.
