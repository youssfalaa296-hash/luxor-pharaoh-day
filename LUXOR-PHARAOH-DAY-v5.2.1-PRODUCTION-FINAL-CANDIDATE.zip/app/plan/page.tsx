import { Planner } from '@/components/Planner';
export default function PlanPage(){return <main className="container routeHero"><p className="eyebrow">GO · تحرك</p><h1><span>خطتي في الأقصر</span><small>My Luxor Plan</small></h1><p className="muted">اختياراتك تُحفظ على جهازك محليًا، ولا تحتاج حسابًا في هذه المرحلة.</p><Planner /></main>}
