import Link from 'next/link';
import { HeroScene } from '@/components/HeroScene';
import { ExperienceCard } from '@/components/ExperienceCard';
import { Planner } from '@/components/Planner';
import { experiences, attractions, siteConfig } from '@/lib/data';

export default function Home() {
  return <main>
    <section className="hero container">
      <div className="heroGrid">
        <div className="heroCopy">
          <div className="kicker">LUXOR · YOUR PHARAOH DAY</div>
          <h1><span>أبرز تجربة اليوم الفرعوني في الأقصر</span><small>Your Pharaoh Day in Luxor</small></h1>
          <p className="heroLead">اعرف ماذا تفعل، اتأكد من المعلومات قبل الاختيار، ثم تحرك بخطوة واضحة — KNOW · CHECK · GO.</p>
          <div className="ctaRow"><Link className="cta" href="/experiences">استكشف اليوم · Explore</Link><Link className="ghost" href="/plan">ابدأ خطتك · Build a plan</Link></div>
          <div className="infoBand"><strong>شفافية أولًا · Transparency first</strong><br />كل معلومة لها حالة واضحة، والمعلومات المتغيرة تُراجع مقابل مصدرها قبل اعتمادها.</div>
        </div>
        <HeroScene />
      </div>
    </section>
    <section className="section container">
      <div className="sectionHeader"><div><p className="eyebrow">KNOW · CHECK · GO</p><h2>اختيارات تناسب وقتك</h2><small>Options shaped around your time</small></div><Link href="/experiences">كل التجارب · All experiences</Link></div>
      <div className="grid">{experiences.map((item)=><ExperienceCard key={item.id} item={item}/>)}</div>
      <Planner />
      <section className="sourcePanel" aria-labelledby="source-title">
        <div>
          <p className="eyebrow">CHECK · SOURCES</p>
          <h2 id="source-title"><span>مصادر الأسعار والمواعيد</span><small>Price & opening-hour sources</small></h2>
          <p className="muted">المعلومات المنشورة أدناه مرتبطة بصفحات وزارة السياحة والآثار المصرية، مع تاريخ آخر مراجعة داخل النظام.</p>
        </div>
        <div className="sourceRows">
          {attractions.slice(0,3).map((item) => (
            <div className="sourceRow" key={item.id}>
              <span><strong>{item.titleAr}</strong><small>{item.titleEn}</small></span>
              <span>{item.hours}</span>
              <span>أجنبي بالغ · {item.foreignerAdult} ج.م</span>
              <a href={item.sourceUrl} target="_blank" rel="noopener noreferrer">المصدر · Source ↗</a>
            </div>
          ))}
        </div>
      </section>
    </section>
  </main>;
}
