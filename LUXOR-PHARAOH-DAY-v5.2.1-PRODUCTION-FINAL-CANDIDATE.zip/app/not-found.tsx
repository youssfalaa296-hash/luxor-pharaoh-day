import Link from 'next/link';
export default function NotFound(){return <main className="container legal"><p className="eyebrow">404 · NOT FOUND</p><h1><span>الصفحة مش موجودة</span><small>Page not found</small></h1><p className="muted">ارجع للبداية واكتشف يومك في الأقصر. · Return home and build your Luxor day.</p><Link className="cta" href="/">العودة للرئيسية · Home</Link></main>}
