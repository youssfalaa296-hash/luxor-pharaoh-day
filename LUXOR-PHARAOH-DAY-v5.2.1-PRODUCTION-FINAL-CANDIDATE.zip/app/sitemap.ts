import type { MetadataRoute } from 'next';

const base = process.env.NEXT_PUBLIC_SITE_URL || 'https://luxor-pharaoh-day.vercel.app';
const lastModified = new Date('2026-09-27T00:00:00Z');

export default function sitemap(): MetadataRoute.Sitemap {
  return ['', '/experiences', '/plan', '/transport', '/before-you-buy', '/privacy', '/terms'].map((path) => ({
    url: `${base}${path}`,
    lastModified
  }));
}
