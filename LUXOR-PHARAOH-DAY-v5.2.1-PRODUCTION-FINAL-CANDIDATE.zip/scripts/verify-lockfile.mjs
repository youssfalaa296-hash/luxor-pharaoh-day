import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const lockPath = path.join(root, 'package-lock.json');
if (!fs.existsSync(lockPath)) {
  console.error('package-lock.json is missing. Generate it with Node 24.21.0 / npm 11.19.0.');
  process.exit(1);
}
const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (lock.lockfileVersion !== 3) {
  console.error(`Expected lockfileVersion 3; found ${lock.lockfileVersion}`);
  process.exit(1);
}
if (lock.packages?.['']?.name !== pkg.name) {
  console.error('Lockfile root package name does not match package.json.');
  process.exit(1);
}
const specs = {...pkg.dependencies, ...pkg.devDependencies};
for (const [name, spec] of Object.entries(specs)) {
  const got = lock.packages?.['']?.dependencies?.[name] ?? lock.packages?.['']?.devDependencies?.[name];
  if (got !== spec) {
    console.error(`Lockfile dependency mismatch: ${name}: ${got} !== ${spec}`);
    process.exit(1);
  }
}
console.log('package-lock.json contract passed.');
