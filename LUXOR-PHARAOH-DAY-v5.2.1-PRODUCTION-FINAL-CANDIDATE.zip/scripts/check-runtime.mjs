import { execFileSync } from 'node:child_process';

const requiredNode = '24.21.0';
const requiredNpmMajor = 11;
const nodeVersion = process.versions.node;
const npmVersion = execFileSync('npm', ['--version'], { encoding: 'utf8' }).trim();
const npmMajor = Number(npmVersion.split('.')[0]);

if (nodeVersion !== requiredNode) {
  console.error(`Runtime gate failed: Node ${requiredNode} required; found ${nodeVersion}`);
  process.exit(1);
}
if (npmMajor !== requiredNpmMajor) {
  console.error(`Runtime gate failed: npm ${requiredNpmMajor}.x required; found ${npmVersion}`);
  process.exit(1);
}
console.log(`Runtime gate passed: Node ${nodeVersion} / npm ${npmVersion}`);
