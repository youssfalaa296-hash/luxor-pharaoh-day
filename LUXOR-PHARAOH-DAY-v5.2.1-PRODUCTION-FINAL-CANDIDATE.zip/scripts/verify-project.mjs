import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'package.json', '.nvmrc', '.node-version', '.npmrc', 'vercel.json',
  'app/layout.tsx', 'app/page.tsx', 'app/error.tsx', 'app/global-error.tsx',
  'app/loading.tsx', 'app/not-found.tsx', 'app/robots.ts', 'app/sitemap.ts',
  'app/manifest.webmanifest', 'public/luxor-pharaoh-day-hero.svg',
  'lib/data.ts', 'scripts/check-runtime.mjs', 'scripts/verify-project.mjs',
  'scripts/verify-lockfile.mjs', '.github/workflows/bootstrap-lockfile.yml',
  '.github/workflows/production-ci.yml'
];
const forbidden = [
  'hello@luxorpharaohday.example', 'phone.example'
];
let failed = false;
for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) {
    console.error(`Missing required path: ${rel}`);
    failed = true;
  }
}
for (const rel of ['app','components','lib','public','scripts']) {
  const dir = path.join(root, rel);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
    console.error(`Missing required directory: ${rel}`);
    failed = true;
  }
}
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (packageJson.packageManager !== 'npm@11.19.0') {
  console.error('packageManager must be npm@11.19.0'); failed = true;
}
if (packageJson.engines?.node !== '24.21.0' || packageJson.engines?.npm !== '>=11 <12') {
  console.error('package.json engines are not locked to the production runtime contract'); failed = true;
}
function walk(dir) {
  const files = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory() && !['node_modules','.next','.git'].includes(ent.name)) files.push(...walk(full));
    else if (ent.isFile()) files.push(full);
  }
  return files;
}
for (const file of walk(root).filter((file) => !file.endsWith(path.join('scripts', 'verify-project.mjs')))) {
  const text = fs.readFileSync(file, 'utf8');
  for (const token of forbidden) {
    if (text.includes(token)) {
      console.error(`Forbidden hard-coded token/placeholder found in ${path.relative(root,file)}: ${token}`);
      failed = true;
    }
  }
}
if (failed) process.exit(1);
console.log('Project structure and safety contract passed.');
