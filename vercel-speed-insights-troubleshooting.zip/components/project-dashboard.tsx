'use client'

import { useState } from 'react'
import {
  Activity,
  ArrowLeft,
  Check,
  ChevronDown,
  CircleHelp,
  ExternalLink,
  FolderKanban,
  GitBranch,
  Globe2,
  Menu,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  Search,
  Settings,
  Sparkles,
  Trash2,
  Triangle,
  X,
} from 'lucide-react'

const projects = [
  { name: 'luxor-quest', framework: 'Next.js', status: 'نشط', domain: 'luxor-quest.vercel.app', updated: 'منذ 12 دقيقة' },
  { name: 'marketing-site', framework: 'Next.js', status: 'نشط', domain: 'marketing-site.vercel.app', updated: 'منذ ساعتين' },
  { name: 'docs-platform', framework: 'Astro', status: 'متوقف مؤقتًا', domain: 'docs-platform.vercel.app', updated: 'أمس' },
]

export function ProjectDashboard() {
  const [paused, setPaused] = useState(false)
  const [showDelete, setShowDelete] = useState(false)
  const [search, setSearch] = useState('')
  const filtered = projects.filter((project) => project.name.includes(search.toLowerCase()))

  return (
    <div dir="rtl" className="min-h-screen bg-[#fafafa] text-[#1d1d1f]">
      <header className="border-b border-black/[0.08] bg-white">
        <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between px-5 lg:px-10">
          <div className="flex items-center gap-5">
            <button className="rounded-md p-2 hover:bg-black/[0.05] lg:hidden" aria-label="فتح القائمة"><Menu /></button>
            <div className="flex items-center gap-2"><Triangle className="size-5 fill-black" /><span className="text-lg font-semibold tracking-tight">Vercel</span></div>
            <span className="text-black/20">/</span>
            <div className="flex items-center gap-2 text-sm font-medium"><span className="flex size-6 items-center justify-center rounded bg-black text-[10px] text-white">LQ</span> Luxor Quest <ChevronDown className="size-4 text-black/40" /></div>
          </div>
          <div className="flex items-center gap-2"><button className="hidden rounded-md px-3 py-2 text-sm text-black/60 hover:bg-black/[0.05] sm:block">مركز المساعدة</button><button className="flex size-9 items-center justify-center rounded-full bg-black text-xs font-medium text-white" aria-label="حساب المستخدم">م</button></div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1440px]">
        <aside className="hidden min-h-[calc(100vh-65px)] w-64 border-l border-black/[0.08] bg-white p-4 lg:block">
          <nav className="flex flex-col gap-1 text-sm">
            <p className="px-3 pb-2 pt-2 text-xs font-medium text-black/40">المشروع</p>
            <SideLink icon={<Activity />} label="نظرة عامة" active />
            <SideLink icon={<GitBranch />} label="عمليات النشر" />
            <SideLink icon={<Globe2 />} label="النطاقات" />
            <SideLink icon={<Settings />} label="الإعدادات" />
            <p className="px-3 pb-2 pt-8 text-xs font-medium text-black/40">الفريق</p>
            <SideLink icon={<FolderKanban />} label="كل المشاريع" />
            <SideLink icon={<CircleHelp />} label="المساعدة والدعم" />
          </nav>
          <div className="mt-10 rounded-lg border border-black/[0.08] bg-[#fafafa] p-4"><Sparkles className="mb-3 size-4" /><p className="text-sm font-medium">انشر أسرع مع Vercel</p><p className="mt-1 text-xs leading-5 text-black/50">اكتشف أدوات تساعد فريقك على البناء والنشر بشكل أفضل.</p><button className="mt-3 text-xs font-medium underline underline-offset-4">معرفة المزيد</button></div>
        </aside>

        <main className="min-w-0 flex-1 px-5 py-8 lg:px-12 lg:py-12">
          <div className="mx-auto max-w-5xl">
            <div className="mb-9 flex flex-col justify-between gap-5 sm:flex-row sm:items-start"><div><div className="mb-3 flex items-center gap-2 text-sm text-black/45"><span>المشاريع</span><ArrowLeft className="size-3" /><span>Luxor Quest</span></div><h1 className="text-3xl font-semibold tracking-tight">إدارة المشروع</h1><p className="mt-2 text-sm text-black/50">إدارة إعدادات مشروعك وعمليات النشر والنطاقات.</p></div><button className="flex items-center justify-center gap-2 rounded-md bg-black px-4 py-2.5 text-sm font-medium text-white hover:bg-black/80"><Plus className="size-4" /> مشروع جديد</button></div>

            <section className="rounded-xl border border-black/[0.1] bg-white shadow-[0_1px_2px_rgba(0,0,0,.03)]">
              <div className="flex flex-col gap-4 border-b border-black/[0.08] p-5 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="font-semibold">المشاريع</h2><p className="mt-1 text-sm text-black/50">كل المشاريع المرتبطة بفريقك.</p></div><div className="relative"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-black/35" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث في المشاريع" className="h-9 w-full rounded-md border border-black/[0.12] bg-white pr-9 pl-3 text-sm outline-none placeholder:text-black/35 focus:border-black sm:w-56" /></div></div>
              <div className="divide-y divide-black/[0.07]">{filtered.map((project) => <ProjectRow key={project.name} project={project} />)}{filtered.length === 0 && <p className="p-8 text-center text-sm text-black/50">لا توجد مشاريع مطابقة.</p>}</div>
            </section>

            <section className="mt-8 rounded-xl border border-black/[0.1] bg-white"><div className="flex items-center justify-between border-b border-black/[0.08] p-5"><div><h2 className="font-semibold">إدارة حالة المشروع</h2><p className="mt-1 text-sm text-black/50">أوقف المشروع مؤقتًا لتقليل استخدام الموارد.</p></div><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${paused ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}>{paused ? 'متوقف مؤقتًا' : 'نشط'}</span></div><div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-medium">{paused ? 'استئناف المشروع' : 'إيقاف المشروع مؤقتًا'}</p><p className="mt-1 max-w-xl text-sm leading-6 text-black/50">{paused ? 'أعد تشغيل عمليات النشر والإنتاج. سيعود المشروع للعمل خلال دقائق.' : 'لن يتمكن الزوار من الوصول إلى نشر الإنتاج أثناء الإيقاف، ولن تُحتسب موارد مدفوعة.'}</p></div><button onClick={() => setPaused(!paused)} className={`flex shrink-0 items-center justify-center gap-2 rounded-md border px-4 py-2 text-sm font-medium ${paused ? 'border-black bg-black text-white' : 'border-black/[0.15] bg-white hover:bg-black/[0.04]'}`}>{paused ? <Play className="size-4" /> : <Pause className="size-4" />}{paused ? 'استئناف المشروع' : 'إيقاف مؤقت'}</button></div></section>

            <section className="mt-8 rounded-xl border border-red-200 bg-white"><div className="border-b border-red-100 p-5"><h2 className="font-semibold text-red-700">منطقة الخطر</h2><p className="mt-1 text-sm text-black/50">الإجراءات هنا قد تؤثر بشكل دائم على مشروعك.</p></div><div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-medium">حذف المشروع</p><p className="mt-1 text-sm text-black/50">سيؤدي ذلك إلى حذف عمليات النشر والنطاقات والإعدادات المرتبطة به.</p></div><button onClick={() => setShowDelete(true)} className="flex items-center justify-center gap-2 rounded-md border border-red-200 px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50"><Trash2 className="size-4" /> حذف المشروع</button></div></section>
          </div>
        </main>
      </div>
      {showDelete && <DeleteDialog onClose={() => setShowDelete(false)} />}
    </div>
  )
}

function SideLink({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) { return <button className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-right ${active ? 'bg-black/[0.06] font-medium' : 'text-black/60 hover:bg-black/[0.04]'}`}>{icon}{label}</button> }
function ProjectRow({ project }: { project: (typeof projects)[number] }) { return <div className="flex flex-col gap-4 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><div className="flex size-9 items-center justify-center rounded-lg border border-black/[0.1] bg-white"><Triangle className="size-4 fill-black" /></div><div><p className="text-sm font-medium">{project.name}</p><p className="mt-1 text-xs text-black/45">{project.framework} · {project.updated}</p></div></div><div className="flex items-center justify-between gap-5 sm:justify-end"><span className={`flex items-center gap-1.5 text-xs ${project.status === 'نشط' ? 'text-emerald-700' : 'text-amber-700'}`}><span className="size-1.5 rounded-full bg-current" />{project.status}</span><span className="hidden text-xs text-black/45 md:block">{project.domain}</span><button className="rounded-md p-1.5 text-black/45 hover:bg-black/[0.06]" aria-label={`خيارات ${project.name}`}><MoreHorizontal className="size-4" /></button></div></div> }
function DeleteDialog({ onClose }: { onClose: () => void }) { return <div className="fixed inset-0 z-10 flex items-center justify-center bg-black/30 p-5" role="dialog" aria-modal="true" aria-labelledby="delete-title"><div className="w-full max-w-md rounded-xl border border-black/[0.1] bg-white p-6 shadow-2xl"><div className="mb-5 flex items-start justify-between"><div><h2 id="delete-title" className="font-semibold">حذف المشروع؟</h2><p className="mt-2 text-sm leading-6 text-black/55">هذا الإجراء لا يمكن التراجع عنه. اكتب <strong className="font-medium text-black">luxor-quest</strong> للتأكيد.</p></div><button onClick={onClose} aria-label="إغلاق" className="rounded-md p-1 text-black/45 hover:bg-black/[0.06]"><X className="size-4" /></button></div><input aria-label="اسم المشروع للتأكيد" className="mb-5 h-10 w-full rounded-md border border-black/[0.15] px-3 text-sm outline-none focus:border-black" placeholder="اسم المشروع" /><div className="flex justify-end gap-2"><button onClick={onClose} className="rounded-md px-4 py-2 text-sm hover:bg-black/[0.05]">إلغاء</button><button onClick={onClose} className="rounded-md bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"><Check className="mr-2 inline size-4" /> حذف نهائي</button></div></div></div> }

export default ProjectDashboard

// Keep this import used by the current icon set in older lucide builds.
void ExternalLink
void Settings
void Globe2
void GitBranch
void FolderKanban
void Search
void Activity
void Sparkles
void MoreHorizontal
void Menu
void ChevronDown
void ArrowLeft
void CircleHelp
void Pause
void Play
void Trash2
void X
void Check
void Triangle
void Plus
void useState
